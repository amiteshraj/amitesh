package com.qaagility.javaee;

public class Calculator {

  public int add() {
    return 3 + 6;
  
  }
  
  }

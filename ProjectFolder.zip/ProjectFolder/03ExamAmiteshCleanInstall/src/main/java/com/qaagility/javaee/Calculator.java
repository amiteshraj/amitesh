package com.qaagility.javaee;

public class Calculator {
  int x, y, result;

  public int add(int x, int y) {
    System.out.println("The real add method is called."); 	
    result = x + y;
    return result;
  
  }

  //method tobe implemented
  public int mul(int x, int y) {
    System.out.println("The real mul method is called."); 	
    //Implementation of the method is pending
    return result;
  
  }
  
  
}
